#include "stdafx.h"
#include<iostream>
#include <conio.h>
#include "MatrixLib.h"
 
using namespace std;

void MatrixLib::Class1::multiplication(int in1[3][3], int in2[3][3]){
	int k = 0;
	int sum = 0;
	int l = 0;
	int out[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int h = 0; h < 3; h++){
			for (int j = 0; j < 3; j++){
				k = in1[i][j] * in2[j][h];
				sum += k;
			}
			out[i][h] = sum;
			sum = 0;
		}
		
	}

	for (int a = 0; a < 3; a++){
		for (int b = 0; b < 3; b++){
			cout << out[a][b]<<" ";
		}
	}
	 
}