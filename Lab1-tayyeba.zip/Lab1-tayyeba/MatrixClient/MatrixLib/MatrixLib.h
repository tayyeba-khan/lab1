// MatrixLib.h

#pragma once

using namespace System;

namespace MatrixLib {

	public ref class Class1
	{
		void subtract();
		void add();
		void multiplication(int in1[3][3], int in2[3][3]);
		// TODO: Add your methods for this class here.
	};
}
