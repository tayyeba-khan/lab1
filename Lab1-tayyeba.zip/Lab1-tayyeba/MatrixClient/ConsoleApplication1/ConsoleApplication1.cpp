// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "MatrixLib.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int in1[3][3] = { { 1, 1, 1 }, { 1, 1, 1 }, { 1, 1, 1 } };
	int in2[3][3] = { { 1, 1, 1 }, { 1, 1, 1 }, { 1, 1, 1 } };
    MatrixLib::Class1::multiplication(in1, in2);
	MatrixLib::Class1::Add();
	MatrixLib::Class1::Subtraction();
	return 0;
}

